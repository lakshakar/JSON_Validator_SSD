{/* {


    // Object.keys(scene_json._scenename).map((key, i) => (
    //     <div>
    //         <p className="prop_name">&#9656; Prop {i} : {key}</p>
    //         <p className="prop_value"> Constraint : {scene_json._scenename[key]}</p>
    //     </div>
    // ))



    // let validator_keys = Object.keys(scene_json);

} */}